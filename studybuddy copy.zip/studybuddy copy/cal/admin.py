from django.contrib import admin
from .models import date

admin.site.register(date)

#add or delete specific date and task from admin panel
